# Karigar Saathi PWA

A mobile-first, dependency-free working prototype for an AI virtual business manager for artisans and micro entrepreneurs.

## Run locally

Use any static server. For example

```bash
python3 -m http.server 8080 --directory karigar-saathi-pwa
```

Then open `http://localhost:8080`.

## Included

- Responsive Hindi-first UI
- Product catalogue with search and filters
- Guided three-step AI product listing flow
- Local image upload and preview
- Simulated image enhancement, bilingual copy generation, and pricing guidance
- Order status workflow
- Sales insights and downloadable CSV report
- LocalStorage persistence
- Offline service worker and installable web app manifest
- Keyboard and reduced-motion accessibility support

## Production integration points

Replace the simulated AI functions in `app.js` with authenticated backend endpoints for image enhancement, catalog generation, pricing, inventory, orders, and marketplace publishing. Never expose provider API keys in browser code.
